import { useEffect, useState } from "react";
import { Box, Typography, TextField, Button, InputAdornment } from "@mui/material";
import { ImagePlus, X, ArrowLeft } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import AdminLayout from "../components/AdminLayout";
import DynamicPointsField from "../components/DynamicPointsField";
import { getCategoryById, updateCategory } from "../utils/categoriesStorage";

const fileToBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

const formatDisplayDate = (isoDate) => {
  if (!isoDate) return "";
  const d = new Date(`${isoDate}T00:00:00`);
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
};

const fieldSx = {
  "& .MuiOutlinedInput-root": { borderRadius: "8px", fontSize: "13px" },
};
const labelSx = { fontSize: "12px", fontWeight: 500, color: "text.secondary", mb: 1 };

const KategoryDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [notFound, setNotFound] = useState(false);
  const [form, setForm] = useState({
    name: "",
    date: "",
    time: "",
    location: "",
    description: "",
    quota: "",
    price: "",
  });
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [terms, setTerms] = useState([""]);
  const [facilities, setFacilities] = useState([""]);

  useEffect(() => {
    const ev = getCategoryById(id);
    if (!ev) {
      setNotFound(true);
      return;
    }

    setForm({
      name: ev.name || "",
      date: ev.dateISO || "",
      time: ev.time || "",
      location: ev.venue || "",
      description: ev.description || "",
      quota: ev.quota ?? "",
      price: ev.price ?? "",
    });
    setImagePreview(ev.image || null);
    setTerms(ev.terms && ev.terms.length ? [...ev.terms, ""] : [""]);
    setFacilities(ev.facilities && ev.facilities.length ? [...ev.facilities, ""] : [""]);
  }, [id]);

  const handleChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImage(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const handleRemoveImage = () => {
    setImage(null);
    setImagePreview(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const imageData = image ? await fileToBase64(image) : imagePreview;

    updateCategory(id, {
      name: form.name,
      date: formatDisplayDate(form.date),
      dateISO: form.date,
      time: form.time,
      venue: form.location,
      description: form.description,
      terms: terms.filter((t) => t.trim() !== ""),
      facilities: facilities.filter((f) => f.trim() !== ""),
      price: Number(form.price) || 0,
      quota: Number(form.quota) || 0,
      image: imageData,
    });

    navigate("/admin/events");
  };

  if (notFound) {
    return (
      <AdminLayout>
        <Box
          sx={{
            textAlign: "center",
            py: 8,
            color: "text.secondary",
            border: "1.5px dashed",
            borderColor: "border.main",
            borderRadius: "10px",
            backgroundColor: "#FFFFFF",
          }}
        >
          <Typography sx={{ fontWeight: 700, color: "text.primary", mb: 0.5 }}>
            Event tidak ditemukan
          </Typography>
          <Button
            onClick={() => navigate("/admin/events")}
            sx={{ textTransform: "none", mt: 1.5 }}
          >
            ← Kembali ke Semua Event
          </Button>
        </Box>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <Box sx={{ width: "100%", boxSizing: "border-box" }}>
        <Box
          onClick={() => navigate("/admin/events")}
          sx={{
            display: "inline-flex",
            alignItems: "center",
            gap: 0.75,
            color: "text.secondary",
            fontSize: "12px",
            cursor: "pointer",
            mb: 1.5,
            "&:hover": { color: "primary.main" },
          }}
        >
          <ArrowLeft size={14} /> Kembali ke Semua Event
        </Box>

        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontSize: { xs: "22px", sm: "24px", md: "26px" },
              fontWeight: 700,
              lineHeight: 1.2,
              color: "text.primary",
            }}
          >
            Detail Event
          </Typography>
          <Typography sx={{ mt: 0.6, fontSize: { xs: "11px", sm: "12px" }, color: "text.secondary" }}>
            Lihat dan ubah detail event ini.
          </Typography>
        </Box>

        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            backgroundColor: "#FFFFFF",
            border: "1px solid",
            borderColor: "border.main",
            borderRadius: "10px",
            p: { xs: 2, md: 3 },
            display: "flex",
            flexDirection: "column",
            gap: 2.5,
            width: "100%",
          }}
        >
          <Box>
            <Typography sx={labelSx}>Nama Event</Typography>
            <TextField
              fullWidth
              size="small"
              value={form.name}
              onChange={handleChange("name")}
              sx={fieldSx}
            />
          </Box>

          <Box>
            <Typography sx={labelSx}>Gambar Event</Typography>

            {imagePreview ? (
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <Box sx={{ position: "relative", display: "inline-block" }}>
                  <Box
                    component="img"
                    src={imagePreview}
                    alt="Preview event"
                    sx={{
                      display: "block",
                      width: "auto",
                      height: "auto",
                      maxWidth: 720,
                      maxHeight: 240,
                      borderRadius: "10px",
                      border: "1px solid",
                      borderColor: "border.main",
                    }}
                  />
                  <Box
                    onClick={handleRemoveImage}
                    sx={{
                      position: "absolute",
                      top: 8,
                      right: 8,
                      width: 26,
                      height: 26,
                      borderRadius: "50%",
                      bgcolor: "rgba(0,0,0,.6)",
                      color: "#fff",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                    }}
                  >
                    <X size={14} />
                  </Box>
                </Box>
              </Box>
            ) : (
              <Box
                component="label"
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 1,
                  width: "100%",
                  maxWidth: 320,
                  height: 140,
                  borderRadius: "10px",
                  border: "1.5px dashed",
                  borderColor: "border.main",
                  color: "text.secondary",
                  cursor: "pointer",
                  "&:hover": { borderColor: "primary.main", color: "primary.main" },
                }}
              >
                <ImagePlus size={22} />
                <Typography sx={{ fontSize: "12px" }}>Klik untuk upload gambar</Typography>
                <input type="file" accept="image/*" hidden onChange={handleImageChange} />
              </Box>
            )}
          </Box>

          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Box sx={{ flex: 1, minWidth: 180 }}>
              <Typography sx={labelSx}>Tanggal Event</Typography>
              <TextField
                fullWidth
                size="small"
                type="date"
                value={form.date}
                onChange={handleChange("date")}
                sx={fieldSx}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
            <Box sx={{ flex: 1, minWidth: 140 }}>
              <Typography sx={labelSx}>Jam Event</Typography>
              <TextField
                fullWidth
                size="small"
                type="time"
                value={form.time}
                onChange={handleChange("time")}
                sx={fieldSx}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
          </Box>

          <Box>
            <Typography sx={labelSx}>Lokasi Event</Typography>
            <TextField
              fullWidth
              size="small"
              value={form.location}
              onChange={handleChange("location")}
              sx={fieldSx}
            />
          </Box>

          <Box>
            <Typography sx={labelSx}>Deskripsi Event</Typography>
            <TextField
              fullWidth
              multiline
              minRows={4}
              value={form.description}
              onChange={handleChange("description")}
              sx={fieldSx}
            />
          </Box>

          <DynamicPointsField
            label="Syarat dan Ketentuan Event"
            placeholder="Syarat & ketentuan poin"
            values={terms}
            onChange={setTerms}
          />

          <DynamicPointsField
            label="Fasilitas Event"
            placeholder="Fasilitas poin"
            values={facilities}
            onChange={setFacilities}
          />

          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Box sx={{ flex: 1, minWidth: 180 }}>
              <Typography sx={labelSx}>Jumlah Tiket yang Tersedia</Typography>
              <TextField
                fullWidth
                size="small"
                type="number"
                value={form.quota}
                onChange={handleChange("quota")}
                sx={fieldSx}
              />
            </Box>
            <Box sx={{ flex: 1, minWidth: 180 }}>
              <Typography sx={labelSx}>Harga Tiket</Typography>
              <TextField
                fullWidth
                size="small"
                type="number"
                value={form.price}
                onChange={handleChange("price")}
                sx={fieldSx}
                InputProps={{ startAdornment: <InputAdornment position="start">Rp</InputAdornment> }}
              />
            </Box>
          </Box>

          <Box sx={{ display: "flex", gap: 1.5, justifyContent: "flex-end", pt: 1 }}>
            <Button
              type="button"
              onClick={() => navigate("/admin/events")}
              sx={{ textTransform: "none", color: "text.secondary", fontSize: "13px" }}
            >
              Kembali
            </Button>
            <Button
              type="submit"
              variant="contained"
              sx={{
                textTransform: "none",
                fontSize: "13px",
                fontWeight: 700,
                borderRadius: "8px",
                px: 3,
                bgcolor: "primary.main",
                boxShadow: "none",
                "&:hover": { bgcolor: "#021F8F", boxShadow: "none" },
              }}
            >
              Simpan Perubahan
            </Button>
          </Box>
        </Box>
      </Box>
    </AdminLayout>
  );
};

export default KategoryDetailPage;